<?php

echo "Hello there good sir";
echo"<br/>";
echo"<br/>";
echo"<br/>";
echo"<br/>";
 phpinfo(); ?>